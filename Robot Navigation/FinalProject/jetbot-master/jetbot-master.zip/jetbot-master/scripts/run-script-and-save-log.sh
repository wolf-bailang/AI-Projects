#!/bin/bash

./create-sdcard-image-from-scratch.sh 2>&1 | tee ~/jetbot-create-sdcard-image.log
